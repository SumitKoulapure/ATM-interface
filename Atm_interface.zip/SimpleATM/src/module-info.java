/**
 * 
 */
/**
 * 
 */
module SimpleATM {
	requires java.sql;
}